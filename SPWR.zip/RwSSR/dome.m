clc;
clear;
%%
load('dataSet/Indian_pines.mat');
load('dataSet/Indian_pines_gt.mat');
data =indian_pines;
gt =indian_pines_gt;
%%
[no_lines, no_rows, no_bands] = size(data);
[X] = re_scale(reshape(data,no_lines*no_rows, no_bands)); 
[N,L] = size(X);
k_num = [3,5,7,9];
lamada1_num = [1e-3,1e-2,1e-1,1,1e1,1e2,1e3];
lamada2_num =  [1e-3,1e-2,1e-1,1,1e1,1e2,1e3];
alpha_num =  [1e-3,1e-2,1e-1,1,1e1,1e2,1e3];
max_iter =100;
tol = 1e-6; 
delta = 1e-7;
diag_idx = logical(eye(L)); 
%%
hsi = reshape(X,no_lines,no_rows,no_bands);  
label_super_pixel= importdata('lables\indian_pines\100.mat');
[Xs_list,Xs_gt_list,max_label] = createXsList2(hsi,gt,label_super_pixel);
sum_Xs=cell(max_label +1);  
for index_Xs=1:length(Xs_list)
        Xs = Xs_list{index_Xs};
        Xs_double = im2double(Xs);
        sum_Xs{index_Xs}=  Xs_double'*Xs_double;
end              
As_list=cell(max_label +1);
for index_Xs=1:length(Xs_list)
  As_list{index_Xs}=zeros(L); 
end
Ws_list=cell(max_label +1);
for index_Xs=1:length(Xs_list)
    Ws_list{index_Xs}=0;
end 
Ls_list=cell(max_label +1);
for index_Xs=1:length(Xs_list)
 Xs = Xs_list{index_Xs};
 Ls = ConstructGraph(Xs',k);  
 Ls_list{index_Xs}=Ls;
end
 I = eye(L);
 A = zeros(L); 
 obj = []; 
 res_A = []; 
 res_As=[]; 
 res_Ws=[]; 
for iter = 1:max_iter  
for i = 1:no_bands
    u(i) = 1./(2*sqrt(A(i,:)*A(i,:)'+ delta));
end
  U = diag(u);
  sumAS=0;
  sumWs=0;
for index_Xs=1:length(Xs_list) 
As_new=pinv(2*sum_Xs{index_Xs}+2*lamada1*Ws_list{index_Xs}*I+lamada2*(Ls_list{index_Xs}'+Ls_list{index_Xs}))*(2*sum_Xs{index_Xs}+2*lamada1*A*Ws_list{index_Xs}); 
As_new(As_new<0)=0;
As_new(diag_idx)=0;
sumAS=sumAS+norm(As_new-As_list{index_Xs},1);
Residual = As_new-A;
f=norm(Residual,'fro');
Ws_new=pinv(2*f)*1;  
sumWs=sumWs+norm(Ws_new-Ws_list{index_Xs},1);
Ws_list{index_Xs}=Ws_new;
As_list{index_Xs}=As_new;
end 
    sum1=0;
    sum2=0;
    sum3=0; 
    F=zeros(L);
    sum_Ws=0;
   for index_Xs=1:length(Xs_list)
        sum_Ws=sum_Ws+Ws_list{index_Xs};
        F=F+Ws_list{index_Xs}*As_list{index_Xs};
        mind1 =Xs_list{index_Xs}-Xs_list{index_Xs}*As_list{index_Xs};
        f1=norm(mind1,'fro')*norm(mind1,'fro');
        sum1=sum1+f1;
        mind2 = As_list{index_Xs}-A;
        f2=Ws_list{index_Xs}*norm(mind2,'fro')*norm(mind2,'fro');
        sum2=sum2+f2;
        f3= trace(As_list{index_Xs}'*Ls_list{index_Xs}*As_list{index_Xs});
        sum3=sum3+f3;
   end
    A_new=pinv(alpha*(U'+U)+2*lamada1*I*sum_Ws)*2*lamada1*F; 
    res_A(iter) = norm(A-A_new,1);
    res_As(iter)=sumAS;
    res_Ws(iter)=sumWs;
    obj(iter)=sum1+lamada1*sum2+lamada2*sum3+alpha*trace(A'*U*A);

  A=A_new;      
if iter == 1 || mod(iter, 10) == 0
       fprintf('%f iteration compelte, res_A= %f, res_As=%f, res_Ws=%f, obj=%f\n',iter, res_A(iter),res_As(iter),res_Ws(iter),obj(iter));
end
    if res_A(iter) <tol
        break;
    end 
end 
  T = sum(A,2);
  [pp,nn] = sort(T,'descend');    
    



      
