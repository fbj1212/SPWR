function [ LH,H ] = ConstructGraph(X, k)
[no_bands,~] = size(X);
for i = 1:no_bands     
    for j = 1:no_bands
        distance(i,j) = (X(i,:)-X(j,:))*(X(i,:)-X(j,:))';
    end
end
[sorted_dis_value,sorted_dis_loc] = sort(distance,2);
hyper_edges = sorted_dis_loc(:,1:k);
hyper_edges_value = sorted_dis_value(:,1:k);
W = zeros(no_bands,1);

for i = 1:no_bands 
    sum_f1_i = (1/k)*sum(sqrt(hyper_edges_value(i,:)));
    sum_f2_i = (1/k)*sum(abs(repmat(hyper_edges(i,1),1,k)-hyper_edges(i,:)));
    for j = 1:k
        f1_i = sorted_dis_value(i,j)./(2*sum_f1_i*sum_f1_i);         
        f2_i = ((hyper_edges(i,1)-hyper_edges(i,j))^2)./(2*sum_f2_i*sum_f2_i);
        fij_i(j) = exp(-f1_i)*exp(-f2_i);  
        sum_f1_j = (1/k)*sum(sqrt(hyper_edges_value(hyper_edges(i,j),:)));
        sum_f2_j = (1/k)*sum(abs(repmat(hyper_edges(hyper_edges(i,j),1),1,k)-hyper_edges(hyper_edges(i,j),:)));
        for p = 1:k
            f1_j = sorted_dis_value(hyper_edges(i,j),p)./(2*sum_f1_j*sum_f1_j);         
            f2_j = ((hyper_edges(hyper_edges(i,j),1)-hyper_edges(hyper_edges(i,j),p))^2)./(2*sum_f2_j*sum_f2_j);
            fij_j(p) = exp(-f1_j)*exp(-f2_j);   
        end
        fij_j_hat = fij_j/sum(fij_j);
        fxj(j,:) = fij_j_hat*X(hyper_edges(hyper_edges(i,j),:),:);
    end
    fij_i_hat = fij_i./sum(fij_i);
    fxi = fij_i_hat*X(hyper_edges(i,:),:);
    sum_fxy = (1/k)*sum(sqrt(diag((repmat(fxi,k,1)-fxj)*(repmat(fxi,k,1)-fxj)')));
    W(i) = sum(exp(-diag((repmat(fxi,k,1)-fxj)*(repmat(fxi,k,1)-fxj)')./(2*sum_fxy*sum_fxy)));
end

H = zeros(no_bands,no_bands);
for i = 1:no_bands
    H(hyper_edges(i,:),i) = 1;
end

Dv = repmat(W,1,no_bands).*H;
Dv = sum(Dv,2);
De = sum(H,1);
W = diag(W)./max(W(:));
Dv = diag(Dv);
De = diag(De);
LH= eye(no_bands) - Dv^(-1/2)*H*W*De^(-1)*H'*Dv^(-1/2);
end

