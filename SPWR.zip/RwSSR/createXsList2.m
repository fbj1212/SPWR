function [Xs_list,Xs_gt_list,max_label] = createXsList2(X,gt,label_super_pixel)

[~,~,num_band] = size(X);
max_label = max(max(label_super_pixel));  
Xs_list = cell(max_label +1);
Xs_gt_list = cell(max_label +1);
for label=0:max_label
    mask = label_super_pixel== label; 
    num_pixel = sum(sum(mask));    
    Xs = zeros(num_pixel,num_band);
    for index_band=1:num_band
        band = X(:,:,index_band);
        Xs(:,index_band) = band(mask);
    end
    Xs_list{label+1} = Xs;
    Xs_gt_list{label+1} = gt(mask);
end
end

